#include <stdio.h>
#include <string.h>

//ogrenci bilgileri icin ogrenci adinda yapinin tanimlanmasi
typedef struct ogrenci{
	int no;
	int birthDate;
	int class;
	char * name;
	char * surname;
	char * sex;
	char * dept;
	struct student *next;
}liste,graduated; //iki adet liste uretilmesi(normal ve mezun)

liste *new, *first = NULL, *temp, *delTemp; //normal liste uzerinde islemler yapabilmek icin pointer(gosterici) tanimlanmasi
graduated *g_new, *g_first = NULL, *g_temp; //mezun liste uzerinde islemler yapabilmek icin pointer(gosterici) tanimlanmasi


//fonksiyon prototipleri
void menu();
void readFile();
int processFile(char[]);
int dateStrInt(char[]);
char dataIntStr(int);
void splitDate(int,int*,int*,int*);
void add(int,int,int,char*,char*,char*,char*);
void showList();
int searchClass(int);
int delete(int);
void increase();
void listDept(char[]);
void listClass(int);


//baslangic fonksiyonu
int main()
{	
	menu();
}

//secimler icin menu tasarimi
void menu()
{
	printf("\n==========================\n");
	printf("1. Take data from file\n");
	printf("2. Increase class\n");
	printf("3. List > Normal\n");
	printf("4. List > Department\n");
	printf("5. List > Graduated\n");
	printf("6. List > Class\n");
	printf("0. Exit");
	printf("\n==========================\n");
	printf("\nChoose > ");
	
	int sec_no;
	scanf("%d",&sec_no);
	
	switch(sec_no)
	{
		case 0:
			exit(1);
		break;
		
		case 1:
			//Dosyadan veri al
			readFile();
		break;
		
		case 2:
			//Sinif arttir
			increase();
		break;
		
		case 3:
			//Normal olarak listele
			showList();
		break;
		
		case 4:
			//Bolume gore listele
			printf("\nWrite department name please > ");
			char dept[10];
			scanf("%s",dept);
			listDept(dept);
		break;
		
		case 5:
			//Mezunlari listele
			listGrad();
		break;
		
		case 6:
			//Sinifa gore listele
			printf("\nEnter the class please > ");
			int class = 1;
			scanf("%d",&class);
			listClass(class);
		break;
		
		default:
			printf("\n\nYou didn't enter valid value!!\a");
			menu();
		break;
	}
}

void add(int no,int birthDate,int class,char *name,char *surname,char *sex,char *dept)
{
	if(first == NULL)
	{
		first = (liste*)malloc(sizeof(liste));
		first->no = no;
		first->birthDate = birthDate;
		first->class = class;
		first->name = name;
		first->surname = surname;
		first->sex = sex;
		first->dept = dept;
		first->next = NULL;
	
	}
	else
	{
		if((first->birthDate) > (birthDate))
		{
			new = (liste*)malloc(sizeof(liste));
			new->no = no;
			new->birthDate = birthDate;
			new->class = class;
			new->name = name;
			new->surname = surname;
			new->sex = sex;
			new->dept = dept;
			first->next = new;
		}
		else
		{
			temp = first;
			new = (liste*)malloc(sizeof(liste));
			new->no = no;
			new->birthDate = birthDate;
			new->class = class;
			new->name = name;
			new->surname = surname;
			new->sex = sex;
			new->dept = dept;
			while(temp != NULL)
			{
				//gecici elemaninin sonraki degeri null ve son elemandan buyukse
				if(temp->next == NULL && (temp->birthDate) <= (birthDate))
				{
					new->next = NULL;
					temp->next = new;
					break;
				}
				//Araya ekleme
				if((temp->next->birthDate) > (birthDate))
				{
					new->next = temp->next;
					temp->next = new;
					break;
				}
				temp = temp->next;
			}
		}
	}
}

//mezun olanlarin mezun listesine eklenmesi
void addGrad(int no,int birthDate,int class,char *name,char *surname,char *sex,char *dept)
{
	class--;
	if(g_first == NULL)
	{
        g_first = (liste)malloc(sizeof(liste));
        g_first->no = no;
        g_first->birthDate = birthDate;
        g_first->class = class;
        g_first->name = name;
        g_first->surname = surname;
        g_first->sex = sex;
        g_first->dept = dept;
        g_first->next = NULL;
	
	}
	else
	{
		if((g_first->birthDate) > (birthDate))
		{
            g_first = (liste*)malloc(sizeof(liste));
            g_first->no = no;
            g_first->birthDate = birthDate;
            g_first->class = class;
            g_first->name = name;
            g_first->surname = surname;
            g_first->sex = sex;
            g_first->dept = dept;
			g_first->next = g_new;
		}
		else
		{
			g_temp = first;
			g_new = (liste*)malloc(sizeof(liste));
			g_new->no = no;
            g_new->birthDate = birthDate;
            g_new->class = class;
            g_new->name = name;
            g_new->surname = surname;
            g_new->sex = sex;
            g_new->dept = dept;
			while(g_temp != NULL)
			{
				//gecici elemaninin sonraki degeri null ve son elemandan buyukse
				if(g_temp->next == NULL && (g_temp->birthDate) <= (birthDate))
				{
					g_new->next = NULL;
					g_temp->next = g_new;
					break;
				}
				//Araya ekleme
				if((g_temp->next->birthDate) > (birthDate))
				{
					g_new->next = g_temp->next;
					g_temp->next = g_new;
					break;
				}
				g_temp = g_temp->next;
			}
		}
	}
}

//normal listeleme yapilmasi
void showList()
{
	if(first == NULL)
		printf("\nThere is no data!!!\n");
	else
	{
		temp = first;
		printf("\nno        \tname\tsurname\tbirthDate\t\tsex.\tdept\tclass\n");
		while(temp != NULL)
		{
			printf("---------------------------------------------------------------------\n");
			int dp,mp,yp;
			splitDate(temp->birthDate,&dp,&mp,&yp);
			printf(
			"%d\t%s\t%s\t%d/%d/%d\t%s\t%s\t%d\n",temp->no,temp->name,temp->surname,dp,mp,yp,temp->sex,temp->dept,temp->class);
			
			temp = temp->next;
		}
	}
	printf("---------------------------------------------------------------------\n");
	menu();
}

//verilen bolum adina gore listeleme yapilmasi
void listDept(char dept[])
{
	if(first == NULL)
		printf("\nThere is no data!!!\n");
	else
	{
		printf("\nDEPARTMENT : %s\n",dept);
		temp = first;
		printf("\nno        \tname\tsurname\tbirthDate\t\tsex\tdept\tclass\n");
		while(temp != NULL)
		{
			if(strcmp(temp->dept,dept) == 0)
			{
				printf("---------------------------------------------------------------------\n");
				int dp,mp,yp;
				splitDate(temp->birthDate,&dp,&mp,&yp);
				printf(
				"%d\t%s\t%s\t%d/%d/%d\t%s\t%s\t%d\n",temp->no,temp->name,temp->surname,dp,mp,yp,temp->sex,temp->dept,temp->class);
			}
			 temp = temp->next;
		}
	}
	printf("---------------------------------------------------------------------\n");
	menu();
}

//sinif degerine gore listeleme yapilmasi
void listClass(int class)
{
	if(first == NULL)
		printf("\nThere is no data!!!\n");
	else
	{
		printf("\nCLASS : %d\n",class);
		temp = first;
        printf("\nno        \tname\tsurname\tbirthDate\t\tsex\tdept\tclass\n");
		while(temp != NULL)
		{
			if(temp->class == class)
			{
				printf("---------------------------------------------------------------------\n");
				int dp,mp,yp;
				splitDate(temp->birthDate,&dp,&mp,&yp);
				printf(
				"%d\t%s\t%s\t%d/%d/%d\t%s\t%s\t%d\n",temp->no,temp->name,temp->surname,dp,mp,yp,temp->sex,temp->dept,temp->class);
			}
			temp = temp->next;
		}
	}
	printf("---------------------------------------------------------------------\n");
	menu();
}

//mezun olanlarin listelenmesi
void listGrad()
{
	if(g_first == NULL)
		printf("\nThere is no data!!!\n");
	else
	{
		g_temp = g_first;
		printf("\nGRADUATED >>\n");
        printf("\nno        \tname\tsurname\tbirthDate\t\tsex\tdept\tclass\n");
		while(g_temp != NULL)
		{
			printf("---------------------------------------------------------------------\n");
			int dp,mp,yp;
			splitDate(g_temp->birthDate,&dp,&mp,&yp);
			printf(
			"%d\t%s\t%s\t%d/%d/%d\t%s\t%s\t%d\n",g_temp->no,g_temp->name,g_temp->surname,dp,mp,yp,g_temp->sex,g_temp->dept,g_temp->class);
			
			g_temp = g_temp->next;
		}
	}
	printf("---------------------------------------------------------------------\n");
	menu();
}

//kullanicidan veri dosyasi icin giris alinmasi
void readFile()
{
	printf("\nENTER THE FILE NAME PLEASE > ");
	char filename[50];
	scanf("%s",filename);
	processFile(filename);
}

//verilen dosya adi uzerinden listeye ekleme yapilmasi
int processFile(char filename[])
{
	if(!fopen(filename,"r"))
	{
		printf("\n\nFILE CAN'T READ!!!\a");
		menu();
	}
	else
	{
		FILE *read;
		read = fopen(filename,"r");
	//	printf("\nno        \tisim\tsoyad\tdogum\t\tcins.\tbolum\tsinif\n");
		
		while(!feof(read)){
			list fileread;
			fileread.name = (char*)malloc(sizeof(char)*100);
			fileread.surname = (char*)malloc(sizeof(char)*100);
			char *birthDate = (char*)malloc(sizeof(char)*100);
			fileread.sex = (char*)malloc(sizeof(char)*5);
			fileread.dept = (char*)malloc(sizeof(char)*5);
		
			fscanf(read,"%d %s %s %s %s %s %d",&fileread.no,fileread.name,fileread.soyisim,birthDate,fileread.sex,fileread.dept,&fileread.class);
			fileread.birthDate = dateStrInt(birthDate);
			
			add(fileread.no,fileread.birthDate,fileread.class,fileread.name,fileread.surname,fileread.sex,fileread.dept);

			int dp,mp,yp;
			splitDate(fileread.birthDate,&dp,&mp,&yp);
			//printf("---------------------------------------------------------------------\n");
		//	printf("%d\t%s\t%s\t%d/%d/%d\t%s\t%s\t%d\n",okunan.no,okunan.isim,okunan.soyisim,dp,mp,yp,okunan.cinsiyet,okunan.bolum,okunan.sinif);
			
		}
		fclose(read);
	}
//	printf("---------------------------------------------------------------------\n");
	menu();		
}

//metinsel olarak verilen tarih verisinin sayisal veriye donusturulmesi
int dateStrInt(char str[])
{
	int day, mounth, year;
	sscanf(str,"%d/%d/%d",&day,&mounth,&year);
	return (year*10000+mounth*100+day);
}

//sayisal olarak verilen tarihin gun,ay,yil seklinde bolunmesi
void splitDate(int ymd, int *dp, int *mp, int *yp)
{
	*dp = ymd % 100;
	*mp = (ymd / 100) % 100;
	*yp = ymd / 10000;
}

//sinif bazinda arama yapma
int searchClass(int class)
{
	int count = 0;
	temp = first;
	
	while(temp != NULL)
	{
		count ++;
		if(temp->class == class)
		{
			printf("FOUND");
			return count;
			
		}
		temp = temp->next;
	}
	return -1;
}

//butun listedeki kayitlarin sinif degerinin 1 arttirilmasi
void increase()
{
	if(first == NULL)
		printf("\nThere is no data!!!\n");
	else
	{
		temp = first;
		while(temp != NULL)
		{
			temp->class += 1;
			temp = temp->next;
		}
		printf("\n>>> Added..\n");
		delGrad(4);
	}
}

//mezun olanlarin normal listeden silinip mezun listesine eklenmesi
int delGrad(int class)
{
	if(first == NULL)
		return 1;
	else if(first->class > class)
	{
		delTemp = first;
		first = first->next;
		printf(">>> Graduated!! [ %d -> %s %s].\n",delTemp->no,delTemp->name,delTemp->surname);
		addGrad(delTemp->no,delTemp->birthDate,delTemp->class,delTemp->name,delTemp->surname,delTemp->sex,delTemp->dept);
		free(delTemp);
		return 1;
	}
	else
	{
		temp = first;
		while(temp->next != NULL)
		{
			if(temp->next->class >class)
			{
				delTemp = temp->next;
				temp->next = delTemp->next;
				printf(">>> Graduated!! [ %d -> %s %s].\n",delTemp->no,delTemp->name,delTemp->surname);
				addGrad(delTemp->no,delTemp->birthDate,delTemp->class,delTemp->name,delTemp->surname,delTemp->sex,delTemp->dept);
				free(delTemp);
				return 1;
			}
			temp = temp->next;
		}
	}
	return 0;
}

/*
  silme bolumunde tek tek silmektedir.
  ayrac olmasi icin ; yerine bosluk(space) kullanilmistir
  ek olarak sinif filtrelemesi eklenmistir
*/

