
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public class Main {

    static int gun_sayisi = 0, backPackItems = 0;
    static float backpackWeight = 0;
    static Scanner scanner = new Scanner(System.in);
    static ArrayList<String[]> clothing = new ArrayList<String[]>();
    static ArrayList<String[]> foodAndDrink = new ArrayList<String[]>();
    static ArrayList<String[]> firstAid = new ArrayList<String[]>();
    static ArrayList<String[]> tool = new ArrayList<String[]>();
    static Stack<String[]> backPack = new Stack<String[]>();
    static double clothingTotalKg = 0, foodAndDrinkTotalKg = 0, firstAidTotalKg = 0, toolTotalKg = 0;

    public static String[] ReadFile(String path) {

        int i = 0;
        int lenght;

        try {
            lenght = Files.readAllLines(Paths.get(path)).size();

            String[] results = new String[lenght];

            for (String line : Files.readAllLines(Paths.get(path))) {
                results[i++] = line;
            }
            return results;

        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }

    }

    public static void main(String[] args) {

        for (String line : ReadFile("items.txt")) {
            switch (line.split(",")[1]) {
                case "0":
                    clothing.add(line.split(","));
                    break;
                case "1":
                    foodAndDrink.add(line.split(","));
                    break;
                case "2":
                    firstAid.add(line.split(","));
                    break;
                case "3":
                    tool.add(line.split(","));
                    break;
            }
        }

        System.out.println("Welcome to Survival Game!");
        while (!(clothing.size() == 0 && foodAndDrink.size() == 0 && firstAid.size() == 0 && tool.size() == 0)) {
            clothingTotalKg = 0;
            foodAndDrinkTotalKg = 0;
            firstAidTotalKg = 0;
            toolTotalKg = 0;
            backPack.clear();
            
            System.out.println("*********************************");

            for (String[] value : clothing) {
                clothingTotalKg += Double.parseDouble(value[2]);
            }
            for (String[] value : foodAndDrink) {
                foodAndDrinkTotalKg += Double.parseDouble(value[2]);
            }
            for (String[] value : firstAid) {
                firstAidTotalKg += Double.parseDouble(value[2]);
            }
            for (String[] value : tool) {
                toolTotalKg += Double.parseDouble(value[2]);
            }

            Menu();

            System.out.println("Select Difficulty:");
            System.out.println("[0] Pilgrim\t[1] Voyager\t[2]Stalker\t[3]Interloper\t[9]Exit");
            int chose = scanner.nextInt();

            System.out.println("\n\n");
            float totalKg = 0, maxKg = 0;
            ItemsView();
            switch (chose) {
                case 0:
                    maxKg = 9;
                    break;
                case 1:
                    maxKg = 7;
                    break;
                case 2:
                    maxKg = 5;
                    break;
                case 3:
                    maxKg = 3;
                    break;
            }
            System.out.println("\n\nMax " + maxKg + " kg !!!\n");
            while (totalKg < maxKg || (maxKg - totalKg) > 0.09) {
                if (clothing.size() == 0 && foodAndDrink.size() == 0 && firstAid.size() == 0 && tool.size() == 0) {
                    BackPackView();
                    Menu();
                    break;
                }
                System.out.print("Item Category : ");
                int categoryId = scanner.nextInt();
                ArrayList<String[]> values = new ArrayList<String[]>();
                switch (categoryId) {
                    case 0:
                        values = clothing;
                        break;
                    case 1:
                        values = foodAndDrink;
                        break;
                    case 2:
                        values = firstAid;
                        break;
                    case 3:
                        values = tool;
                        break;
                }
                scanner.nextLine();
                System.out.print("Item Name : ");
                String itemName = scanner.nextLine();
                String[] item;
                if (DeleteItem(values, itemName) != null) {
                    item = DeleteItem(values, itemName);
                    if (Float.parseFloat(item[2]) + totalKg <= 9) {
                        totalKg += Float.parseFloat(item[2]);
                        backPack.push(item);
                        values.remove(item);
                        System.out.println("Free : " + new DecimalFormat("##.##").format((maxKg - totalKg)));
                        ItemsView();
                    } else {
                        System.err.println("Item does not fit in the backpack!!!");
                        continue;
                    }

                } else {
                    System.err.println("Item not found!!!");
                    continue;
                }

            }
            BackPackView();
        }
        System.out.println("No items left in boxes");

    }

    public static void BackPackView() {
        backpackWeight =0;
        backPackItems = backPack.size();
        System.out.println("Items in Backpack");
        String leftAlignFormat = "| %-18s | %-8s | %-10s | %-5s|%n";
        System.out.format("+--------------------+----------+------------+------+%n");
        System.out.format("| Item Name          | Category | Weight(kg) | Gain |%n");
        System.out.format("+--------------------+----------+------------+------+%n");
        for (String[] strings : backPack) {
            System.out.format(leftAlignFormat, strings[0], strings[1], strings[2], strings[3]);
            gun_sayisi += Integer.parseInt(strings[3]);
            backpackWeight += Float.parseFloat(strings[2]);
        }
        System.out.format("+--------------------+----------+------------+------+%n");

    }

    public static void Menu() {

        System.out.println("Clothing\t" + clothing.size() + " items\t|  " + new DecimalFormat("##.##").format(clothingTotalKg) + " kg");
        System.out.println("Food & Drink\t" + foodAndDrink.size() + " items\t|  " + new DecimalFormat("##.##").format(foodAndDrinkTotalKg) + " kg");
        System.out.println("First Aid\t" + firstAid.size() + " items\t|  " + new DecimalFormat("##.##").format(firstAidTotalKg) + " kg");
        System.out.println("Tool\t\t" + tool.size() + " items\t|  " + new DecimalFormat("##.##").format(toolTotalKg) + " kg");
        if (gun_sayisi != 0) {
            System.out.println("Backpack\t" + backPackItems + " items\t|  " + new DecimalFormat("##.##").format(backpackWeight) + " kg");
            System.out.println("Lifespan\t" + gun_sayisi + " days\t|");
            backpackWeight = 0;
            backPackItems = 0;
            gun_sayisi = 0;
        }
        System.out.println("*********************************");
    }

    public static void ItemsView() {

        String leftAlignFormat = "| %-18s | %-8s | %-10s | %-5s|%n";
        System.out.println("Clothing > 0    Food & Drink > 1    First Aid > 2   Tool >3");
        System.out.format("+--------------------+----------+------------+------+%n");
        System.out.format("| Item Name          | Category | Weight(kg) | Gain |%n");
        System.out.format("+--------------------+----------+------------+------+%n");
        for (String[] value : clothing) {
            System.out.format(leftAlignFormat, value[0], value[1], value[2], value[3]);
        }

        for (String[] value : foodAndDrink) {
            System.out.format(leftAlignFormat, value[0], value[1], value[2], value[3]);
        }

        for (String[] value : firstAid) {
            System.out.format(leftAlignFormat, value[0], value[1], value[2], value[3]);
        }

        for (String[] value : tool) {
            System.out.format(leftAlignFormat, value[0], value[1], value[2], value[3]);
        }
        System.out.format("+--------------------+----------+------------+------+%n");
    }

    public static String[] DeleteItem(ArrayList<String[]> values, String itemName) {
        for (String[] value : values) {
            if (itemName.equals(value[0])) {
                return value;
            }
        }
        return null;
    }

}
