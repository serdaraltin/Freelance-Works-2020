 #-*- coding:utf-8 -*-
import sqlite3
from sqlite3 import Error
import os.path
from os import path

veritabaniDosya = "veritabani.db"


def VeritabaniBaglanti():
	conn = None
	try:
		conn = sqlite3.connect(veritabaniDosya)
		return conn
	except Error as e:
		print(e)

	return conn


def TabloOlustur(conn, sqlTablo):
    try:
        c = conn.cursor()
        c.execute(sqlTablo)
    except Error as hata:
        print("Hata : "+hata)

def VeritabaniOlustur():
	sqlTblBolum = """CREATE TABLE IF NOT EXISTS tbl_bolum (
	id integer PRIMARY KEY,
	ad text NOT NULL);"""

	sqlTblSinif = """CREATE TABLE IF NOT EXISTS tbl_sinif (
	id integer PRIMARY KEY,
	bolum_id integer NOT NULL,
	seviye integer NOT NULL,
	FOREIGN KEY (bolum_id) REFERENCES tbl_bolum (id));"""

	sqlTblDers = """CREATE TABLE IF NOT EXISTS tbl_ders (
	id integer PRIMARY KEY,
	sinif_id integer NOT NULL,
	kod text NOT NULL,
	ad text NOT NULL,
	FOREIGN KEY (sinif_id) REFERENCES tbl_sinif (id));"""

	sqlTblOgrenci = """CREATE TABLE IF NOT EXISTS tbl_ogrenci (
	id integer PRIMARY KEY,
	sinif_id integer NOT NULL,
	no text NOT NULL,
	adsoyad text NOT NULL,
	FOREIGN KEY (sinif_id) REFERENCES tbl_sinif (id));"""

	sqlTblVize = """CREATE TABLE IF NOT EXISTS tbl_vize (
	id integer PRIMARY KEY,
	ogrenci_id integer NOT NULL,
	sinif_id integer NOT NULL,
	puan integer NOT NULL,
	FOREIGN KEY (ogrenci_id) REFERENCES tbl_ogrenci (id),
	FOREIGN KEY (sinif_id) REFERENCES tbl_sinif (id));"""

	sqlTblFinal = """CREATE TABLE IF NOT EXISTS tbl_final (
	id integer PRIMARY KEY,
	ogrenci_id integer NOT NULL,
	sinif_id integer NOT NULL,
	puan integer NOT NULL,
	FOREIGN KEY (ogrenci_id) REFERENCES tbl_ogrenci (id),
	FOREIGN KEY (sinif_id) REFERENCES tbl_sinif (id));"""


	conn = VeritabaniBaglanti()

	if conn is not None:
		TabloOlustur(conn, sqlTblBolum)
		TabloOlustur(conn, sqlTblSinif)
		TabloOlustur(conn, sqlTblDers)
		TabloOlustur(conn, sqlTblOgrenci)
		TabloOlustur(conn, sqlTblVize)
		TabloOlustur(conn, sqlTblFinal)
		BolumEkle("Yazılım Müh.")
		BolumEkle("Endüstri Müh.")
		BolumEkle("Elektrik Müh.")
		BolumEkle("İnşaat Müh.")
	else:
		print("Hata : Veritabanı bağlantısı sağlanamadı.")

def BolumEkle(bolumAd):
	sql = "INSERT INTO tbl_bolum (ad) VALUES('"+bolumAd+"')"

	conn = VeritabaniBaglanti()
	cur = conn.cursor()
	cur.execute(sql)
	return cur.lastrowid

def AnaMenu():
	print("1) Bölümleri Listele")
	print("2) Öğrenci Ara")
	print("3) Çıkış")
	secim = int(input("Seçiminiz: "))
	if(secim == 1):
		BolumMenu()
	elif(secim == 2):
		pass
	elif(secim == 3):
		pass
	else:
		print("Hatalı seçim yaptınız.Tekrar seçiniz!")
	AnaMenu()

def BolumMenu():
	print("1) Yazılım Müh.")
	print("2) Endüstri Müh.")
	print("3) Elektrik Müh.")
	print("4) İnşaat Müh.")
	bolumNo = int(input("İşlem yapmak istediğiniz bölüm numarasını giriniz: "))
	sinifNo = int(input("İşlem yapmak istediğiniz sınıfı giriniz: "))
	
	if(sinifNo == 1):
		DersMenu()
	elif(secim == 2):
		pass
	elif(secim == 3):
		pass
	elif(secim == 4):
		pass
	else:
		print("Hatalı seçim yaptınız.Tekrar seçiniz!")
	BolumMenu()

def DersMenu():
	print("1) Öğrencileri Listele 2) Dersleri Listele 3) Not Girişi")
	print("4) Öğrenci Ekle/Sil    5) Ders Ekle/Sil    6) Ana Menu")
	secim = int(input("Seçiminiz: "))
	if(secim == 1):
		pass
	elif(secim == 2):
		pass
	elif(secim == 3):
		pass
	elif(secim == 4):
		pass
	elif(secim == 5):
		pass
	elif(secim == 6):
		AnaMenu()
	else:
		print("Hatalı seçim yaptınız.Tekrar seçiniz!")

def OgrenciAra():
	pass

def OgrenciAra():
	pass

def OgrencileriListe():
	pass

def OgrenciEkleSil():
	pass

def DersleriListele():
	pass

def DersEkleSil():
	pass

def NotGirisi():
	pass

def Cikis():
	print("Program kapatılıyor...")
	quit()

if not path.exists(veritabaniDosya):
	VeritabaniOlustur()
AnaMenu()