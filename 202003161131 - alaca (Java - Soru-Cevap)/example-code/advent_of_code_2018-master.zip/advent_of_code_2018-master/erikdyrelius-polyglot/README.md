# Attempts for solutions of AoC 2018 (Polyglot)

My contributions to solutions for [Advent of Code 2018](https://adventofcode.com).

In this repo I will concentrate on trying to solve the problems in so many
programming languages as I can. I will try to document how (and why) they can
be tested and what environment I have used.

Expect this to be a hobby prject that will run for a while after AoC2018 and 
probably be forgotten and start to mold in a few months.