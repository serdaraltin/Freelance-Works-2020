## Usage

The following assume [Leiningen][lein] is installed.

Run a single day:

    $ lein run 1

Run a single day with your own input:

    $ lein run 1 day1.txt
    $ lein run 1 - < day1.txt

Run all:

    $ lein run


[lein]: https://leiningen.org/
