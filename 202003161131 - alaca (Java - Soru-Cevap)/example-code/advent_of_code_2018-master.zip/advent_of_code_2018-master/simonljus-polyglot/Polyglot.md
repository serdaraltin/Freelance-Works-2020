# Polyglot 
Lösningar i olika språk som jag inte har skrivit i tidigare.

## Dag 1
Rust 
