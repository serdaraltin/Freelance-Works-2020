module.exports = {
  env: {
    node: true
  },
  extends: "eslint:recommended",
  parserOptions: {
    ecmaVersion: 2018
  },
  rules: {
    "no-console": 0
  }
};
