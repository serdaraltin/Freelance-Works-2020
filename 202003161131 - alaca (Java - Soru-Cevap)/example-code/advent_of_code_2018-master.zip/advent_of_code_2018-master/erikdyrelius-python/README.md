# Attempts for solutions of AoC 2018 (Python)

My contributions to solutions for [Advent of Code 2018](https://adventofcode.com).

In this repo I will concentrate on fast and ugly solutions in Python3
