Advent of code 2016

Compile with

`g++ $day${a,b}.cpp -o $day${a,b}`

E.g.

`g++ 1b.cpp -o 1b`

Run with

`./$day${a,b} < $day.in`

E.g.

`./1b < 1.in`
