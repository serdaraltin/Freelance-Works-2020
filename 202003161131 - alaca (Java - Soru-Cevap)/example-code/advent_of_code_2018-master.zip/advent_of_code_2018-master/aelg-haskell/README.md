Build 
--
`stack build`

Run
--
Add your session key to sessionKey.txt

`echo -n "123456789abcdef..." > sessionKey.txt`

Run single day

`stack run -- <day#>`

Run all days

`stack run`
