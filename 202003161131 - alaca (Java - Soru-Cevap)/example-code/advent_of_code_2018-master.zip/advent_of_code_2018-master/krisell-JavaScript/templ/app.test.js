const Logger = require('../modules/Logger')
const Tester = require('../modules/Tester')

// require('../modules/AugmentArray')()
// require('../modules/AugmentString')()

// const Grid = require('../modules/GridMover')
// let g = new Grid()

const T = new Tester(app)
const L = new Logger(true)

const cases = {

}
// cases[``] = 
T.basic(cases)


function app (input) {	
	
}