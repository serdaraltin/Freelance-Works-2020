# Advent of Code 2018
Solutions will probably be in python 3.
## Instructions to run:
python3 day*.py
