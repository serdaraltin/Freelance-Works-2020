# Code Template für die Übung 1 aus Programmieren 2

- Forken Sie das Projekt
- Clonen Sie Ihr Projekt in der IDE (IntellJ oder Eclipse)
- Das Projekt muss als Maven Projekt aufgesetzt werden damit die JUnit libaries geladen werden
- Der Folder /src/main/java muss als source root markiert sein
- Der Folder /src/test/java muss als test root markiert sein
- Der Folder /src/test/resoures muss als test resource folder markiert sein
- Schreiben Sie Ihre Testcases unter /test/java/
- Im Order resources können Files mit Testdaten abgelegt werden
- Eine Klasse TestUtils steht zur Verfügung der nur der Filenamen übergeben werden muss und die Zeilen als String zurückliefert

