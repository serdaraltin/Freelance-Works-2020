
import java.util.ArrayList;
import java.util.Scanner;

public class Driver {

    static Scanner scn = new Scanner(System.in);
    static Instructor instructors;

    public static void main(String[] args) {

        System.out.println("Student Automation Project (Enter the Coice)");
        System.out.println("********************************************");
        Menu();

    }

    public static void Menu() {

        System.out.println("1. Courses List");
        System.out.println("2. Add/Remove Course");
        System.out.println("3. Course Students (<courseCode>)");
        System.out.println("4. Intructors List");
        System.out.println("5. Add/Remove Instructor");
        System.out.println("6. Students List");
        System.out.println("7. Add/Remove Student");
        System.out.println("8. Student Info (<studentNo>)");
        System.out.println("9. Add/Remove Student to/from the Course");
        System.out.println("Press 0 for exit.\n");

        int choice;

        choice = scn.nextInt();
        switch (choice) {
            case 0:
                System.exit(0);
                break;
            case 1:
                CourseList();
                break;
            case 2:
                AddRemoveCourse();
                break;
            case 3:
                CourseStudents();
                break;
            case 4:
                InstructorsList();
                break;
            case 5:
                AddRemoveInstructor();
                break;
            case 6:
                StudentsList();
                break;
            case 7:
                AddRemoveStudent();
                break;
            case 8:
                StudentInfo();
                break;
            case 9:
                AddRemoveStudentToCourse();
                break;
            default:
                System.out.println("Choice is not true !\nTry again.");
                break;
        }
        System.out.println("\n");
        Menu();
    }

    public static void CourseList() {
        System.out.println("ALL COURSES");
        System.out.println("***********");
    }

    public static void AddRemoveCourse() {

    }

    public static void CourseStudents() {

    }

    public static void InstructorsList() {
        System.out.println("ALL INSTRUCTORS");
        System.out.println("***************");
        System.out.println("ID Name Surname");

    }

    public static void AddRemoveInstructor() {
        System.out.println("Add Instructor\t  : add # <nameSurname> # <age>");
        System.out.println("Remove Instructor : remove # <instructor ID>");

        System.out.print("Comman [add/remove] : ");
        String command = scn.next();

        if (command.equals("add")) {
            System.out.print("Name : ");
            String nameSurname = scn.next();
            System.out.print("Surnmae : ");
            nameSurname += " " + scn.next();

            System.out.print("Age : ");
            int age = scn.nextInt();

            System.out.println(nameSurname + " " + age);

        }

    }

    public static void StudentsList() {
        System.out.println("ALL STUDENTS");
        System.out.println("************");

    }

    public static void AddRemoveStudent() {

    }

    public static void StudentInfo() {

    }

    public static void AddRemoveStudentToCourse() {

    }

}
