/**
* @file Dosya adı
* @description Programınızın açıklaması ne yaptığına dair.
* @course Dersi aldığınız eğitim türü ve grup
* @assignment Kaçıncı ödev olduğu
* @date Kodu oluşturduğunuz Tarih
* @author Öğrencinin Adı Soyadı
*/


int EnBuyuk(int a, int b)  {  
	if(a < b)
		return b;
	if(a == b)
		return a;
	return a; 
}  