public interface Transport {
    public String City();
    public double Fare();
}
