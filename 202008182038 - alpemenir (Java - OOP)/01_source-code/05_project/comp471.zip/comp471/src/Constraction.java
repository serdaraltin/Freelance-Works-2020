
import java.util.ArrayList;

public interface Constraction {
    public ArrayList<String> GetMaterial();
    public String Compose();
}
