import java.util.ArrayList;

/**
 *
 * @author acar
 */
public class Knapsack {
    
    
    //fields
    
    public Knapsack(double capacity)
    {
        
       
    }

    public double getCapacity() {
       
    }

    public ArrayList<Item> getItems() {
       
    }

    public void setCapacity(double capacity) {
       
    }

    public void setItems(ArrayList<Item> items) {
       
    }
    
    public boolean pushItem(Item item){
     
         
     
     }
    
     public double getMaximumValue(ArrayList<Item> newItems)
     {
       
     
     
     }
     
     public ArrayList<Item> getMaximalItemSet(ArrayList<Item> newItems)
     {
       
     
     }
    
    
    
    
}