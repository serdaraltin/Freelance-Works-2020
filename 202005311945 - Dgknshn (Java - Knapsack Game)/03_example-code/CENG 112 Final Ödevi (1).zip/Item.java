import java.util.ArrayList;
import java.util.List;

/**
 *

 */
public class Item<E> implements Comparable {
    
    // Fields
    
    
    public  Item(double value, double weight){
    
     
    }

    public void setValue(double value) {
        
        
        
    }

    public void setWeight(double weight) {
       
    }

    public double getValue() {
      
    }

    public double getWeight() {
       
    }
    
    
    
    public ArrayList<Item> sort(ArrayList<Item>  itemL){
        
        
        
    }
    

    @Override
    public int compareTo(Object o) {
       
       
       
    }

    
    
}
