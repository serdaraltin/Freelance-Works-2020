# json2csv

Convert JSON file to CSV

For Sublime Text 2 users, there is also a plugin available here: [https://github.com/drugo76/sublime_json2csv](https://github.com/drugo76/sublime_json2csv)

## Usage

```bash
python json2csv.py -i INPUT_JSON_FILE -o OUPUT_CSV_FILE
```
