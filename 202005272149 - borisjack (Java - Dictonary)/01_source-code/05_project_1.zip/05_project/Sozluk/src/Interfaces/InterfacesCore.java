
package Interfaces;

import java.sql.Connection;


public interface InterfacesCore {
    public Connection getConnection();
}
