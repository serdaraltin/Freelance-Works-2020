# Puzzle Program

This is a puzzle solver program. Program structure is based on entering text file as an input (puzzle.txt for example) and solve the words using hints. I put text files as an example and you can create your own puzzle and solve it by using this program.
