#ifndef YASURET_H
#define YASURET_H

int yasekle(){
	return rast(1,100);
}

#endif

