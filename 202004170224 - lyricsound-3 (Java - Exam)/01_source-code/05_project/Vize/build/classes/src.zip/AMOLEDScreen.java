
public class AMOLEDScreen extends Screen {
    public AMOLEDScreen(int dpi, String resulation) {
        super(dpi, resulation, "amoled");
    }
}
