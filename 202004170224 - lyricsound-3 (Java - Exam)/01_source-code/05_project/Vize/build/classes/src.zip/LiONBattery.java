
public class LiONBattery extends Battery {

    public LiONBattery(int mAH, boolean fastRecharge) {
        super(mAH, fastRecharge,"lion");
    }


}
