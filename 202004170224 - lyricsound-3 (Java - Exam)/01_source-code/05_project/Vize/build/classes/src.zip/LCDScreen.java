
public class LCDScreen extends Screen {

    public LCDScreen(int dpi, String resulation) {
        super(dpi, resulation, "lcd");
    }
}
