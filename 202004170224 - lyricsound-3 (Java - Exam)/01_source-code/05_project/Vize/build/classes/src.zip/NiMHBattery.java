
public class NiMHBattery extends Battery {
    public NiMHBattery(int mAH, boolean fastRecharge) {
        super(mAH, fastRecharge,"nimh");
    }
}
