#include <iostream>
#include "people.hpp"

using namespace std;

People::People(){
    nm = "";
    btd = 0;
    wei = 0;
}

