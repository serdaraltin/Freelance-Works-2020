# Day-1-Chronal-Calibration
Advent of Code

A solution to Day 1 of the Advent of Code
