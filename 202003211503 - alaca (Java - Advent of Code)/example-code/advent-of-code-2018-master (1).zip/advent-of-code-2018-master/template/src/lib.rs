pub fn solve_puzzle_part_1(input: &str) -> String {
    unimplemented!();
}

pub fn solve_puzzle_part_2(input: &str) -> String {
    unimplemented!();
}
