extern crate advent_of_code_20xx_day_x;

use advent_of_code_20xx_day_x::*;

#[test]
fn part_1_example() {
    unimplemented!()
}
