#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <iostream>

#define TEST 0
using namespace std;

void FileRead(char*);
int Ebob(int,int);
void ListPrint(struct Node*);


struct Node 
{ 
    int data; 
    struct Node *next; 
    struct Node *prev; 
}; 

void insertEnd(struct Node** start, int value) { 
  
    if (*start == NULL) { 
        struct Node* new_node = new Node; 
        new_node->data = value; 
        new_node->next = new_node->prev = new_node; 
        *start = new_node; 
        return; 
    } 

    Node *last = (*start)->prev; 

    struct Node* new_node = new Node; 
    new_node->data = value; 
    new_node->next = *start; 
    (*start)->prev = new_node; 
    new_node->prev = last; 
    last->next = new_node; 
} 
  

void insertBegin(struct Node** start, int value) { 
    
    struct Node *last = (*start)->prev; 
  
    struct Node* new_node = new Node; 
    new_node->data = value;  
    new_node->next = *start; 
    new_node->prev = last; 
  
    last->next = (*start)->prev = new_node; 

    *start = new_node; 
} 
  

void insertAfter(struct Node** start, int value1,int value2) { 
    struct Node* new_node = new Node; 
    new_node->data = value1;
    
    struct Node *temp = *start; 
    while (temp->data != value2) 
        temp = temp->next; 
    struct Node *next = temp->next; 
  
    temp->next = new_node; 
    new_node->prev = temp; 
    new_node->next = next; 
    next->prev = new_node; 
} 
  
  
void display(struct Node* start) 
{ 
    struct Node *temp = start; 
  
    printf("\n--------------------------\n"); 
    while (temp->next != start) 
    { 
        printf("|%d|<->", temp->data); 
        temp = temp->next; 
    } 
    printf("|%d|\n", temp->data); 
} 
 


int Ebob(int n1, int n2){
	while(n1 != n2){
		if(n1 > n2)
			n1 -= n2;
		else
			n2 -= n1;
	}
	return n1;
}

void FileRead(char *fileName){
	FILE* filePointer;
	int bufferLength = 8192;
	char buffer[bufferLength];

	filePointer = fopen(fileName, "r");

	while(fgets(buffer, bufferLength, filePointer)) {
		int *array = (int*)malloc(sizeof(int)*512);
		
		char delimiter[2] = " ";
		char *token;
		token = strtok(buffer,delimiter);

		int i = 0;
		while(token != NULL){
			array[i++] = atoi(token);
			token = strtok(NULL,delimiter);
		}

		int maxEbob = 0;
		struct Node* start = NULL;
		

	    int j;
	    if(TEST){
		    printf("Line : ");
	 		for(j=0; j<i; j++){
	 			printf("%d ",array[j] );
	 		}
	 		printf("\n");
 		}

	    for(j=0; j<i; j++){

	    	if(j==0){
	    		insertEnd(&start, array[0]); 
				continue;
	    	}
	    	if(maxEbob < Ebob(start->data,array[j])){
	    		if(TEST)
	    			printf("-> %d\n",array[j] );
	    		maxEbob = Ebob(start->data,array[j]);
	    		int mod;
	    		if(array[j] > start->data)
	    			mod = array[j] % start->data;
	    		else
	    			mod = start->data % array[j];
	    		if(TEST)
	    			printf("%d %d , ebob = %d ,mod = %d\n",start->data,array[j],Ebob(start->data,array[j]),mod );
	    	
	    		if(mod == 0){
	    			insertAfter(&start,array[j],start->data);
	    			continue;
	    		}
	    		else{
	    			int i=0;
	    			struct Node *temp = start;
	    			while(i++<mod)
	    				temp = temp->prev;
	    			if(temp == start){
	    				insertBegin(&start,array[j]);
	    				continue;
	    			}
	    		}
	    	}
	    	else{
	    		if(TEST)
	    			printf("<- %d\n",array[j] );
	    		struct Node *temp = start;
	    		while(Ebob(temp->data,array[j]) < maxEbob && temp->next != start){
	    			if(TEST)
	    				printf(" %d - %d \n",temp->data,array[j] );
	    			temp = temp->next;
	    		}
	    		int mod;
	    		if(array[j] > temp->data)
	    			mod = array[j] % temp->data;
	    		else
	    			mod = temp->data % array[j];
	    		if(TEST){
	    			printf(" %d %d , ebob = %d ,mod = %d\n",temp->data,array[j],Ebob(temp->data,array[j]),mod );
	    			printf("%d\n",temp->prev->data );
	    		}
	    		int i=0,flag=0;
	    		while(i++<mod){
	    			if(temp == start){
	    				flag =1;
	    				insertBegin(&start,array[j]);
	    				break;
	    			}
	    			temp = temp->prev;
	    		}
	    		if(flag==0)
	    			insertAfter(&temp,array[j],temp->data);
	    	}
	    if(TEST)
	     display(start); 
	    }
	    if(TEST){
		   printf("END");
		   display(start); 
		}
	    ListPrint(start);
	    free(start);
	}

	fclose(filePointer);
}

void ListPrint(struct Node* start){
	struct Node *temp = start; 
  
    printf("Sifre: "); 
    while (temp->next != start) 
    { 

        printf("%c", temp->data); 
        temp = temp->next; 
    } 
    printf("%c\n", temp->data); 
}