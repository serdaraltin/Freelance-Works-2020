#include "../include/myLib.h"

int main() 
{ 
  
  	char file[15] = "sayilar.txt";
    FileRead(file);
  	
    return 0; 
} 
 
