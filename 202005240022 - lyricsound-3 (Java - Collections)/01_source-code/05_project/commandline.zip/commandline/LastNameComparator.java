import java.util.ArrayList;
import java.util.Collections;

public class LastNameComparator {

    public static ArrayList<Contact> LastNameComparatorArrayList(ArrayList<Contact> contacts) {
        Collections.sort(contacts);
        return contacts;
    }
    

}
