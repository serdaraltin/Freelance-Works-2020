package lyricsound;

import java.util.ArrayList;
import java.util.Collections;
import java.util.TreeSet;

public class LastNameComparator {

    public static ArrayList<Contact> LastNameComparatorArrayList(ArrayList<Contact> contacts) {
        Collections.sort(contacts);
        return contacts;
    }
    

}
