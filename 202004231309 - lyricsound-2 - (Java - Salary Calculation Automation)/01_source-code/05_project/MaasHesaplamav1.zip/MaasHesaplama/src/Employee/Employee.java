package Employee;

import Personnel.Personnel;

public class Employee extends Personnel{
     
    public Employee(String name, String surname, String registerNumber, String position, int yearOfStart) {
        super(name, surname, registerNumber, position, yearOfStart);
    }
     
}
