# Rastgele-Kisi-Ureten-Java-Kutuphanesi
Java Programlama Dilinde Rastgele Kişi Üreten Kütüphane Yazılmıştır. Üretilen her kişi için Tc kimlik nu(Tc Kimlik Algoritmasına Göre) , Imei nu (Imei nu algoritmasına göre),Telefon nu(Tc kurallarına uygun), Metin belgesindeki rastgele 3000 isim ve soy isim, yaş üretilmektedir.
