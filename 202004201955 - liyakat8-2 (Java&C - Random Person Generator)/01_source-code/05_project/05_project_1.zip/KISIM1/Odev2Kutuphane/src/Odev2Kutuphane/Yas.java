package Odev2Kutuphane;

public class Yas {

    private final Rastgele rakamuret = new Rastgele();

    public int Yas() {
        return rakamuret.random(100);
    }
}
