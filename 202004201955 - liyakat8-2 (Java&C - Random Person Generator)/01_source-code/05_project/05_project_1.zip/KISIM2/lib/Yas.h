#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>

int YasUret();

int YasUret(){
	return rast(1,100);
}
