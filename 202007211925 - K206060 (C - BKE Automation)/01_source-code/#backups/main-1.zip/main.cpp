#include <iostream>

using namespace std;

void Menu();
void DiyetMenu();

struct diyet
{
	int grMiktari;
	int siviMiktari;
	int adetMiktari;
	struct diyet *sonraki;
};
typedef struct diyet Diyet;

struct diyetler
{	
	struct diyet *diyet;
	struct diyetler *sol,*sag;
};
typedef sturct diyetler Diyetler;

struct musteri
{
	int diyetNo[10];
	int yas;
	int boy;
	int kilo;
	int kategori;
	float BKE;
	struct diyetler *diyetListesi = NULL;
};
typedef struct musteri Musteri;


float BKEHesapla(int kilo, int boy){
	float boyM = (float)boy/100.0;
	return kilo / (boyM*boyM);
}

void KategoriBelirle(Musteri *musteri){
	int i;
	float BKE = BKEHesapla(musteri->kilo,musteri->boy);
	musteri->BKE = BKE;

	if(BKE < 18.49){
		int diyet[10] = {5,9,8,7,6,4,3,8,6,4};
		for(i=0; i<10; i++)
			musteri->diyetNo[i] = diyet[i];
		musteri->kategori = 1;
		return;
	}
	else if(BKE > 18.49 && BKE < 24.99){
		int diyet[10] = {1,5,9,7,0,3,6,8,4,2};
		for(i=0; i<10; i++)
			musteri->diyetNo[i] = diyet[i];
		musteri->kategori = 2;
		return;
	}
	else if(BKE > 24.99 && BKE < 29.99){
		int diyet[10] = {1,0,3,2,3,1,4,6,0,2};
		for(i=0; i<10; i++)
			musteri->diyetNo[i] = diyet[i];
		musteri->kategori = 3;
		return;
	}
	else if(BKE > 30.00){
		int diyet[10] = {1,0,0,2,0,1,3,0,0,1};
		for(i=0; i<10; i++)
			musteri->diyetNo[i] = diyet[i];
		musteri->kategori = 4;
		return;
	}
}

void MusteriYazdir(Musteri *musteri){
	printf("\nMusterinin\n");
	printf("yasi: %d\tboyu: %dcm\tkilosu: %dkg\n",musteri->yas,musteri->boy,musteri->kilo);
	printf("BKE = %.2f ", musteri->BKE);

	if(musteri->kategori == 1)
		printf("(Ideal Kilonun Alti) - ");
	else if(musteri->kategori == 2)
		printf("(Ideal Kilo) - ");
	else if(musteri->kategori == 3)
		printf("(Ideal Kilonun Uzeri) - ");
	else if(musteri->kategori == 4)
		printf("(Ideal Kilonun Cok Uzeri) - ");

	printf("Diyet numarasi ");

	int i;
	for(i=0; i<10; i++)
		printf("%d ",musteri->diyetNo[i]);
	printf("\n");
}

int BoyRakamlarToplam(int boy){
	int sayi = boy, rakam, toplam = 0;

	while(sayi > 0){
		rakam = sayi % 10;
		toplam += rakam;
		sayi /= 10;
	}
	return toplam;
}

void DiyetListesiOlustur(Musteri *musteri){
	int i;
	for(i=0; i<10; i++){

		Diyet *sabah = (Diyet*)malloc(sizeof(Diyet));
		sabah->grMiktari = (musteri->boy) - (musteri->yas) + (musteri->diyetNo[i]);
		sabah->siviMiktari = (musteri->kilo) + (musteri->yas) - (musteri->diyetNo[i]);
		sabah->adetMiktari = musteri->diyetNo[i];

		Diyet *oglen = (Diyet*)malloc(sizeof(Diyet));
		oglen->grMiktari = (musteri->kilo) + (musteri->yas) + (musteri->diyetNo[i]);
		oglen->siviMiktari = (BoyRakamlarToplam(musteri->boy)) + (musteri->diyetNo[i]);
		oglen->adetMiktari = musteri->diyetNo[i];

		Diyet *aksam = (Diyet*)malloc(sizeof(Diyet));
		aksam->grMiktari = (musteri->boy) - (musteri->yas) + (musteri->diyetNo[i]);
		aksam->siviMiktari = (musteri->kilo) + (musteri->yas) - (musteri->diyetNo[i]);
		aksam->adetMiktari = musteri->diyetNo[i];

		sabah->sonraki = oglen;
		oglen->sonraki = aksam;
		aksam->sonraki = NULL;

		musteri->diyetListesi[i] = sabah;

	}
}

void DiyetListesiYazdir(Musteri *musteri){
	printf("\n-----Diyet Listesi------------------------------------\n\n");
	int i;
	for(i=0; i<10; i++){
		Diyet *diyet = musteri->diyetListesi[i];
		Diyet *sabah = diyet;
		Diyet *oglen = sabah->sonraki;
		Diyet *aksam = oglen->sonraki;

		printf("Gun : %d\tDiyet Numarasi : %d\n\n",i+1,musteri->diyetNo[i]);
		printf("Sabah > ");
		printf("%d gr peynir, %d cc sivi, %d adet zeytin\n", sabah->grMiktari,sabah->siviMiktari,sabah->adetMiktari);
		printf("Oglen > ");
		printf("%d gr salata, %d kasik corba, %d adet meyve\n", oglen->grMiktari,oglen->siviMiktari,oglen->adetMiktari);
		printf("Aksam > ");
		printf("%d gr et, %d cc sivi, %d dilim ekmek\n", aksam->grMiktari,aksam->siviMiktari,aksam->adetMiktari);

		printf("------------------------------------------------------\n");
	}
}

int main(){
	Menu();
} 

void Menu(){
	printf("\n");
	printf("1) Diyet Menu\n");
	printf("0) Cikis\n");
	printf("\nSecim : ");
	int secim;
	cin >> secim;

	switch(secim){
		case 0:
			printf("Programdan Cikiliyor...\n");
			exit(0);
			break;
		case 1:
			DiyetMenu();
			break;
		default:
			printf("Hatali secim, tekrar deneyiniz!\n");
			break;
	}
	Menu();
}

void DiyetMenu(){
	printf("\n");
	printf("1) Diyet Olustur\n");
	printf("2) Diyeti Listele (Diyetisyenin onerdigi)\n");
	printf("3) Diyeti Listele (Adet miktari azalacak sekilde)\n");
	printf("0) Ust Menu\n");
	printf("\nSecim : ");
	int secim;
	cin >> secim;

	switch(secim){
		case 0:
			printf("Programdan Cikiliyor...\n");
			return;
			break;
		case 1:
			DiyetOlustur();
			break;
		case 2:
			break;
		case 3:
			break;
		default:
			printf("Hatali secim, tekrar deneyiniz!\n");
			break;
	}
	DiyetMenu();
}


void DiyetOlustur(){
	Musteri *yeni = (Musteri*)malloc(sizeof(Musteri));

	printf("Yas : ");
	cin >> yeni->yas;

	printf("Boy (cm): ");
	cin >> yeni->boy;

	printf("Kilo (kg) : ");
	cin >> yeni->kilo;

}
